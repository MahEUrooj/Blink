# ESP32 Series
This repository is for teaching purposes

To use the ESP32 first of all copy the link below and paste it in preferences tab in Arduino IDE. 
https://dl.espressif.com/dl/package_esp32_index.json

We will do following projects step by step in ESP32.

1) Blink
2) Internal Temperature Sensor
3) PWM Output in ESP32
4) HTTP Client
5) Thingspeak Hall Effect Sensor Monitoring HTTPClient
6) IFTTT IoT Button HTTPClient
